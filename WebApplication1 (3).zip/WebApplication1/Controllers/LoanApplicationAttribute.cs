﻿using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Controllers
{
    [Table("LoanApplicationAttributes")]
    public class LoanApplicationAttribute
    {
        public Guid ApplicationId { get; set; }
        public string CustomerId { get; set; }
        public string ExperianPin { get; set; }
        public DateTime? ApplicationDate { get; set; }
        public int? MARL001 { get; set; }
        public decimal? COREDTI { get; set; }
        public int? Fico { get; set; }
        public int? VantageScore { get; set; }
        public decimal? REQAMT { get; set; }
        public decimal? APP041 { get; set; }
        public decimal? LTI { get; set; }
        public int? SalariedEmployee { get; set; }
        public int? CL105 { get; set; }
        public string PREMIER_IQT9426 { get; set; }
        public string STG_ALL803 { get; set; }
        public string IQT9426N { get; set; }
        public string IQT9427N { get; set; }
        public string PREMIER_REV5020 { get; set; }
        public string STG_REV201 { get; set; }
        public string REV5020N { get; set; }
        public string PREMIER_REV3424 { get; set; }
        public string STG_REV044 { get; set; }
        public string REV3424N { get; set; }
        public string REV7110N { get; set; }
        public string REV041636N { get; set; }
        public decimal? LORATE { get; set; }
        public decimal? PrimaryOfferApr { get; set; }
        public decimal? PrimaryOfferInterestRate { get; set; }
        public DateTime IdentifiedAt { get; set; }
        public decimal? AcceptedApr { get; set; }
        public string MarketParticipantCode { get; set; }
        public int? W001 { get; set; }
    }
}