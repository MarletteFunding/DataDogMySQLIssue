﻿using Dapper;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace WebApplication1.Controllers
{
    public class Sample
    {
        public string Column1 { get; set; }
    }
    public class ValuesController : ApiController
    {
        // GET api/values
        public async Task<IEnumerable<int>> Get()
        {
            int result = calldb();
            return new int[] { result };
        }

        // GET api/values/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }

        static private  int calldb()
        {
            string connectionString = "server=abc;uid=testuser;pwd=Temp1234;database=TestDB;Allow User Variables=True";
            
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                var mysql = "SELECT * FROM sample";
                var result = ( conn.Query<Sample>(mysql)).ToList();
                Console.WriteLine(result.Count);
                conn.Close();
                return result.Count;
            }
        }
    }
}
